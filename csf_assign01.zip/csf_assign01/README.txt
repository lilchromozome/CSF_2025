TODO: list team members, document who did what, discuss
anything interesting about your implementation.
